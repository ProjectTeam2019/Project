<?php
    
    $con = new mysqli("localhost","root","","TasteBuds");
    
  
    
    $query = "select * from shoplist"; //where sid='$sid'";
    
    $rows = $con->query($query);
    
    while ($row = $rows->fetch_assoc()) {
        
        $pp[] = $row;
    }
    
    echo json_encode($pp);
    ?>




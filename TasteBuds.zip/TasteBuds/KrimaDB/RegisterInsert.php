<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$data = file_get_contents('php://input');
$dt  =  json_decode($data);
$user_name = $dt->user_name;
$email = $dt->email;
$password = $dt->password;
echo $query = "insert into register(user_name,email,password) values('$user_name','$email','$password')";
$cn->query($query);
echo "Successful";
?>

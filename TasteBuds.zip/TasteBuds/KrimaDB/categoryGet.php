<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$category_name=$_REQUEST["category_name"];
$category_image=$_REQUEST["category_image"];
$q = mysqli_query($cn,"select * from register where category_name='$category_name');
if (mysqli_num_rows($q)==0) 
{	
	$row = array();
	print_r(json_encode($row));
}
else
{
	while ($row=mysqli_fetch_assoc($q))
    {
		$pp[]=$row;
	}
	echo json_encode($pp);
}
?>

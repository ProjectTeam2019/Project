<?php
$con= new mysqli("localhost","root","","MyDBEmployee");
$id=$_REQUEST["id"];
$name=$_REQUEST["name"];
$address=$_REQUEST["address"];
$mon=$_REQUEST["mon"];
$query="insert into employee(id,name,address,mon) values ('$id','$name','$address','$mon')";
$con->query($query);
echo "Inserted successfully..."
?>
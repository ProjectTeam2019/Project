

import UIKit
import SkyFloatingLabelTextField
import GoogleSignIn

class Home: UIViewController
{
    let objNav = NavigationBar()
    
    var userBarItem = UIBarButtonItem()
    var searchBarItem = UIBarButtonItem()
    var sideBarItem = UIBarButtonItem()
    
    let userBtn = UIButton(type: .custom)
    let searchBtn = UIButton(type: .custom)
    let sideBtn = UIButton(type: .custom)
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nav = navigationController
        nav?.isNavigationBarHidden = true

        navigationItems()
    }
    
    func navigationItems()
    {
        let navbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        let navitem = UINavigationItem(title: "TASTE BUDS")
        
        userBarItem = objNav.createNavItem(btn: userBtn, image: "usericon.png", btnFrame: CGRect(x: self.view.frame.size.width - 30, y: 0, width: 30, height: 30))
        searchBarItem = objNav.createNavItem(btn: searchBtn, image: "searchicon.png", btnFrame: CGRect(x: self.view.frame.size.width - 53, y: 0, width: 53, height: 30))
        sideBarItem = objNav.createNavItem(btn: sideBtn, image: "sidebar.png", btnFrame: CGRect(x: 0, y: 0, width: 30, height: 30))
        
        userBtn.addTarget(self, action: #selector(self.swipeAction), for: .touchUpInside)
        searchBtn.addTarget(self, action: #selector(self.swipeAction), for: .touchUpInside)
        sideBtn.addTarget(self, action: #selector(self.btnAction), for: .touchUpInside)
        
        
        let arr = [userBarItem,searchBarItem]
        
        navitem.leftBarButtonItem = sideBarItem
        navitem.rightBarButtonItems = arr
        navbar.items = [navitem]
        self.view.addSubview(navbar)
    }
    
    @objc func btnAction()
    {
        print("button")
    }
    
    @objc func swipeAction()
    {
        let dif = UserDefaults.standard
        dif.removeObject(forKey: "uname")
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.navigationController?.pushViewController(stb!, animated: true)
         GIDSignIn.sharedInstance().signOut()
    }
}

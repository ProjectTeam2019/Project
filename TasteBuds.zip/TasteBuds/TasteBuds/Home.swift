
import UIKit
import SkyFloatingLabelTextField
import GoogleSignIn

class Home: UIViewController,UITableViewDataSource,UITableViewDelegate
{
    @IBOutlet weak var catTbl: UITableView!
    var idata : [[String:Any]] = []
    var  dic : [String:Any] = [:]
    
    var tbl = UITableView()
    var hidemenu:Bool = true
    let dicMembers = [["name":"Profile","image":"defaultProfile.png"],  ["name":"Home","image":"home.png"],
                      ["name":"Meal Planner","image":"timer.png"],
                      ["name":"Add Available Ingredients","image":"available.png"],
                      ["name":"Create Recipe","image":"createrecipe.png"],["name":"Diet Planner","image":"diet.png"],
                      ["name":"Kitchen Tips","image":"tips.png"],
                        ["name":"Settings","image":"settings.png"],["name":"Contact Us","image":"contact.png"],["name":"FeedBack","image":"feedback.png"],["name":"Terms & Conditions","image":"TandC.png"]]
    
    var vw = UIView()
    @objc var leftSwipe = UISwipeGestureRecognizer()
    let objView = ViewOpacity()
    
    let src = UISearchBar()
    var navbar = UINavigationBar()
    let objNav = NavigationBar()
    
    var userBarItem = UIBarButtonItem()
    var searchBarItem = UIBarButtonItem()
    var sideBarItem = UIBarButtonItem()
    
    let userBtn = UIButton(type: .custom)
    let searchBtn = UIButton(type: .custom)
    let sideBtn = UIButton(type: .custom)

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nav = navigationController
        nav?.isNavigationBarHidden = true

        tbl.tag = 2
        tbl.delegate = self
        tbl.dataSource = self
        leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(setter: self.leftSwipe))
        self.vw.addGestureRecognizer(leftSwipe)
        
        let url = URL(string: "http://localhost/KrimaDB/categoryGet.php");
        let request = URLRequest(url: url!);
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, resp, err) in
            let strrep = String(data: data1!, encoding: String.Encoding.utf8)
            print(strrep as Any)
            do
            {
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]];
                self.idata = jsondata
                print(self.idata)
                DispatchQueue.main.async
                {
                    self.catTbl.reloadData()
                }
                
            }
            catch{}
        }
        datatask.resume()
        
        vw = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
        self.vw.layer.cornerRadius = 10
        objView.viewOp(vw: vw)
        //vw.backgroundColor = UIColor.lightGray
        self.view.addSubview(vw)
        self.vw.addSubview(tbl)
        
        table()
        navigationItems()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        navbar.isHidden = false
    }
    
    @objc func hide()
    {
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: -300, y: 55, width: 300, height: self.view.frame.size.height)
        UIView.commitAnimations()
        hidemenu = true
    }
    
    @objc func showmenu()
    {
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 0, y: 55, width: 300, height: self.view.frame.size.height)
        UIView.commitAnimations()
        hidemenu = false
    }
    
    func table()
    {
        tbl = UITableView(frame: CGRect(x: -300, y: 55, width: 200, height: self.view.frame.size.height), style: .plain)
        tbl.backgroundColor = UIColor.lightGray
        //tbl.separatorStyle = .none
        tbl.dataSource = self
        tbl.delegate = self
        let right = UISwipeGestureRecognizer(target: self, action: #selector(self.showmenu))
        let left = UISwipeGestureRecognizer(target: self, action: #selector(self.size))
        left.direction = .left
        right.direction = .right
        self.view.addGestureRecognizer(right)
        self.view.addGestureRecognizer(left)
        self.view.addSubview(tbl)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView.tag == 1
        {
            return 1
        }
        else
        {
             return dicMembers.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if tableView.tag == 1
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! catTableCell
            cell.textLabel?.text = dic["category_name"] as? String
            return cell
        }
        else
        {
            let img = UIImageView(frame: CGRect(x: 10, y: 25, width: 90, height: 90))
            let lbl = UILabel(frame: CGRect(x: 110, y: 40, width: 140, height: 50))
            
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "menucell")
            let cell = tableView.dequeueReusableCell(withIdentifier: "menucell", for: indexPath)
            let dic = dicMembers[indexPath.row]
            
            img.layer.cornerRadius = 42
            img.clipsToBounds = true
            img.image = UIImage(named: "defaultProfile.png")
            
            lbl.text = "Hello"
            lbl.font = UIFont.systemFont(ofSize: 25.0)
            
            if indexPath.row == 0
            {
                self.tbl.addSubview(img)
                self.tbl.addSubview(lbl)
            }
            else
            {
                cell.textLabel?.text = dic["name"]
                cell.imageView?.image  = UIImage(named: dic["image"]!)
                //return cell
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if tableView.tag == 1
        {
            return 145.0
        }
        else
        {
            if indexPath.row == 0
            {
                return 130.0
            }
            else
            {
                return 50.0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        src.isHidden = true
        if tableView.tag == 1
        {}
        else
        {
            if indexPath.row == 0
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "profile")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 1
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 2
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "meal")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 3
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "availIng")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 4
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "create")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 5
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "diet")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 6
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "tips")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 7
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "settings")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 8
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "contact")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 9
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "feedback")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 10
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "privacy")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            UIView.beginAnimations(nil, context: nil)
             UIView.setAnimationDuration(0.5)
             UIView.setAnimationDelegate(self)
             tbl.frame = CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height)
             UIView.commitAnimations()
        }

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        hide()
        navbar.isHidden = false
        src.isHidden = true
    }
    
    func navigationItems()
    {
        navbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        let navitem = UINavigationItem(title: "TASTE BUDS")
        
        userBarItem = objNav.createNavItem(btn: userBtn, image: "usericon.png", btnFrame: CGRect(x: self.view.frame.size.width - 30, y: 0, width: 30, height: 30))
        searchBarItem = objNav.createNavItem(btn: searchBtn, image: "searchicon.png", btnFrame: CGRect(x: self.view.frame.size.width - 53, y: 0, width: 53, height: 30))
        sideBarItem = objNav.createNavItem(btn: sideBtn, image: "sidebar.png", btnFrame: CGRect(x: 0, y: 0, width: 30, height: 30))
        
        userBtn.addTarget(self, action: #selector(self.userAction), for: .touchUpInside)
        searchBtn.addTarget(self, action: #selector(self.searchAction), for: .touchUpInside)
        sideBtn.addTarget(self, action: #selector(self.sidebarAction), for: .touchUpInside)
        
        
        let arr = [userBarItem,searchBarItem]
        
        navitem.leftBarButtonItem = sideBarItem
        navitem.rightBarButtonItems = arr
        navbar.items = [navitem]
        self.view.addSubview(navbar)
    }
    
    @objc func leftSwipe(sender : UISwipeGestureRecognizer)
    {
        if sender.direction == .left
        {
            navbar.isHidden = false
            hide()
        }
        else if sender.direction == .right
        {
            navbar.isHidden = false
            hide()
        }
    }
    
    func btncancel()
    {
        let btn = UIButton(type: .custom)
        btn.setImage(UIImage(named: "back2.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        btn.frame = CGRect(x: 0, y: 30, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    
    @objc func test(sender:UIButton)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
        navigationController?.pushViewController(stb!, animated: true)
    }
    
    @objc func sidebarAction()
    {
       
        if hidemenu == true
        {
            showmenu()
        }
        else
        {
            navbar.isHidden = false
            hide()
        }
    }
    
    @objc func searchAction()
    {
        btncancel()
        navbar.isHidden = true
        let src = UISearchBar(frame: CGRect(x: 40, y: 25, width: 330, height: 43.5))
        self.view.addSubview(src)
    }
    
    @objc func userAction()
    {
        let dif = UserDefaults.standard
        
        if (dif.value(forKey: "uname") != nil)
        {
            let alt = UIAlertController(title: "LOGOUT", message: "ARE YOU SURE TO LOGOUT", preferredStyle: .alert)
            let no = UIAlertAction(title: "NO", style: .destructive, handler: nil)
            let yes = UIAlertAction(title: "YES", style: .default)
            { (ACTION) in
                
                let dif = UserDefaults.standard
                dif.removeObject(forKey: "uname")
                
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
                self.navigationController?.pushViewController(stb!, animated: true)
                GIDSignIn.sharedInstance().signOut()
            }
            alt.addAction(yes)
            alt.addAction(no)
            self.present(alt, animated: true, completion: nil)
        }
        
        else
        {
            let alt = UIAlertController(title: "LOGIN", message: "DO YOU WANT TO LOGIN?", preferredStyle: .alert)
            let no = UIAlertAction(title: "NO", style: .destructive, handler: nil)
            let yes = UIAlertAction(title: "YES", style: .default)
            { (ACTION) in
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
                self.navigationController?.pushViewController(stb!, animated: true)
                GIDSignIn.sharedInstance().signOut()
            }
            alt.addAction(yes)
            alt.addAction(no)
            self.present(alt, animated: true, completion: nil)
        }
    }
}

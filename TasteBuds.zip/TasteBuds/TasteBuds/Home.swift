//
//  Home.swift
//  TasteBuds
//
//  Created by MAC2 on 26/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class Home: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let nav = navigationController
        nav?.isNavigationBarHidden = false
        
    }
}

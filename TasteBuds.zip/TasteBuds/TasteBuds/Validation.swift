
import UIKit

class Validation: NSObject
{
    func isValidEmail(email:String) -> Bool
    {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: email)
        return result
    }
    
    func isValidPhone(phone: String) -> Bool {
        
        let PHONE_REGEX = "^\\d{5}-\\d{3}-\\d{3}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: phone)
        return result
    }
    
    func isValidMobile(mobile: String) -> Bool {
        
        //STARTING WITH +91 THEN ONE DIGIT START BETWEEN 7 TO 9 THEN ADD 9 DIGIT BETWEEN 0 TO 9 IT PERMITS +919726174054 / 09726174054
        
        let PHONE_REGEX = "^([+][9][1]|[9][1]|[0]){0,1}([7-9]{1})([0-9]{9})$"
        
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: mobile)
        return result
    }
    
    func isValidPassword(pwd: String) -> Bool {
        
        //Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:
        let PHONE_REGEX = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{6,8}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: pwd)
        return result
    }
}


/*
 @IBAction func Emailtextfileddidchange(_ sender: UITextField) {
 
 if isValidEmail(email: txtemail.text!) {
 
 txtemail.rightViewMode = .never
 txtemail.clipsToBounds = true
 txtemail.layer.borderWidth = 1
 txtemail.layer.borderColor = UIColor.green.cgColor
 }
 else {
 
 txtemail.rightViewMode = .whileEditing
 let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
 txtemail.rightView = imgview
 
 txtemail.clipsToBounds = true
 txtemail.layer.borderWidth = 1
 txtemail.layer.borderColor = UIColor.red.cgColor
 }
 lblInstruction.text = "Enter in this format : Firstpart@secondPart.domainname"
 }


 @IBAction func Phonetextfielddidchange(_ sender: UITextField) {
 
 if isValidPhone(phone: txtphone.text!) {
 
 txtphone.rightViewMode = .never
 txtphone.clipsToBounds = true
 txtphone.layer.borderWidth = 1
 txtphone.layer.borderColor = UIColor.green.cgColor
 }
 else {
 
 txtphone.rightViewMode = .whileEditing
 let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
 txtphone.rightView = imgview
 txtphone.clipsToBounds = true
 txtphone.layer.borderWidth = 1
 txtphone.layer.borderColor = UIColor.red.cgColor
 }
 lblInstruction.text = "Enter in this format : 12345-123-123"
 }
 */



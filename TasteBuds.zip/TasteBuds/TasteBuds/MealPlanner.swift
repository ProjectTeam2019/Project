
import UIKit
import GoogleSignIn

class MealPlanner: UIViewController
{
    var objCancel = CancelBtn()                
    var btn = UIButton()
    
    var navbar = UINavigationBar()
    let objNav = NavigationBar()
    
    var navsearchbar = UINavigationBar()
    
    var userBarItem = UIBarButtonItem()
    var searchBarItem = UIBarButtonItem()
    var backItem = UIBarButtonItem()
    
    let userBtn = UIButton(type: .custom)
    let searchBtn = UIButton(type: .custom)
    @objc let backBtn = UIButton(type: .custom)
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        
        btncancel()
        navigationItems()
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        navbar.isHidden = false
    }
    
    func navigationItems()
    {
        navbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        let navitem = UINavigationItem(title: "TASTE BUDS")
        
        userBarItem = objNav.createNavItem(btn: userBtn, image: "usericon.png", btnFrame: CGRect(x: self.view.frame.size.width - 30, y: 0, width: 30, height: 30))
        searchBarItem = objNav.createNavItem(btn: searchBtn, image: "searchicon.png", btnFrame: CGRect(x: self.view.frame.size.width - 53, y: 0, width: 53, height: 30))
        
        userBtn.addTarget(self, action: #selector(self.userAction), for: .touchUpInside)
        searchBtn.addTarget(self, action: #selector(self.searchAction), for: .touchUpInside)
        
        let arr = [userBarItem,searchBarItem]
        
        navitem.rightBarButtonItems = arr
        navbar.items = [navitem]
        self.view.addSubview(navbar)
    }
    
    @objc func searchAction()
    {
        print("search")
        let navitem = UINavigationItem()
        navsearchbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        backItem = objNav.createNavItem(btn: backBtn, image: "back2.png", btnFrame: CGRect(x: 0, y: 0, width: 30, height: 30))
        backBtn.addTarget(self, action: #selector(self.back), for: .touchUpInside)
        navitem.leftBarButtonItem = backItem
        navsearchbar.items = [navitem]
        self.view.addSubview(navsearchbar)
    }
    
    @objc func back()
    {
        navigationItems()
    }
    
    @objc func userAction()
    {
        let alt = UIAlertController(title: "ALERT", message: "ARE YOU SURE TO LOGOUT", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default) { (ACTION) in
            
            let dif = UserDefaults.standard
            dif.removeObject(forKey: "uname")
            
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
            self.navigationController?.pushViewController(stb!, animated: true)
            GIDSignIn.sharedInstance().signOut()
        }
        let cancel = UIAlertAction(title: "CANCEL", style: .destructive, handler: nil)
        alt.addAction(ok)
        alt.addAction(cancel)
        self.present(alt, animated: true, completion: nil)
    }
    
    func btncancel()
    {
        btn = objCancel.btncancel()
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        self.view.addSubview(btn)
    }
    
    @objc func test(sender:UIButton)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
}

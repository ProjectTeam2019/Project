import UIKit
import SkyFloatingLabelTextField
import TransitionButton

var val = Validation()
class Register: UIViewController
{
    let cont = Controls()
    let objView = ViewOpacity()
    var reg = TransitionButton()
    var user = SkyFloatingLabelTextField()
    var email = SkyFloatingLabelTextField()
    var pass = SkyFloatingLabelTextField()
    var cpass = SkyFloatingLabelTextField()
    @IBOutlet weak var regView: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        
        self.regView.layer.cornerRadius = 10
        objView.viewOp(vw: regView)
        
        txtField()
        btn()
        btncancel()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.regView.endEditing(true)
    }
    
    func btn()
    {
        reg = cont.custombutton(frame: CGRect(x: 115, y: 359, width: 100, height: 30), bgcolor: UIColor.gray, title: "INSCRIBE", radius: 20, spicolor: UIColor.white)
        
        reg.addTarget(self, action: #selector(self.btnReg), for: .touchUpInside)
        self.regView.addSubview(reg)
    }
    
    func btncancel()
    {
        let btn = UIButton(type: .custom)
        btn.setImage(UIImage(named: "blackcross.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    
    @objc func test(sender:UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    func txtField()
    {
        user = cont.customtext(frame: CGRect(x: 53, y: 59, width: 237, height: 40), placeholder: "Username", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Username Here", selTitleCol: UIColor.blue, secure: false)
        user.addTarget(self, action: #selector(self.actUser), for: .editingChanged)
        self.regView.addSubview(user)
        
        email = cont.customtext(frame: CGRect(x: 53, y: 129, width: 237, height: 40), placeholder: "Email ID", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Email ID Here", selTitleCol: UIColor.blue, secure: false)
        email.addTarget(self, action: #selector(self.actEmail), for: .editingChanged)
        self.regView.addSubview(email)
        
        pass = cont.customtext(frame: CGRect(x: 53, y: 199, width: 237, height: 40), placeholder: "Password", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Password Here", selTitleCol: UIColor.blue, secure: true)
        pass.addTarget(self, action: #selector(self.actPass), for: .editingChanged)
        self.regView.addSubview(pass)
        
        cpass = cont.customtext(frame: CGRect(x: 53, y: 269, width: 237, height: 40), placeholder: "Confirm Password", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Confirm Password Here", selTitleCol: UIColor.blue, secure: true)
        cpass.addTarget(self, action: #selector(self.actCpass), for: .editingChanged)
        self.regView.addSubview(cpass)
    }
        
    @objc func actEmail()
    {
        if val.isValidEmail(email: email.text!) {
            
            email.rightViewMode = .never
        }
        else {
            
            email.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "error@2x.png"))
            email.rightView = imgview
            //email.selectedLineColor = UIColor.red
        }
    }
    @objc func actUser()
    {
        if val.isValidUsername(user: user.text!)
        {
            user.rightViewMode = .never
        }
        else
        {
            user.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "error@2x.png"))
            user.rightView = imgview
            //user.selectedLineColor = UIColor.red
        }
    }
    @objc func actPass()
    {
        if val.isValidPassword(pwd: pass.text!) {
            
            pass.rightViewMode = .never
        }
        else {
            
            pass.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "error@2x.png"))
            pass.rightView = imgview
            //pass.selectedLineColor = UIColor.red
        }
    }
    @objc func actCpass()
    {
        if val.isValidCPassword(pwd: self.pass.text!, cpass: self.cpass.text!) {
            
            cpass.rightViewMode = .never
        }
        else {
            
            cpass.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "error@2x.png"))
            cpass.rightView = imgview
            //cpass.selectedLineColor = UIColor.red
        }
    }
    
    @objc func btnReg()
    {
        reg.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute:
        {
            sleep(3)
            DispatchQueue.main.async(execute:
            { () -> Void in
                self.reg.stopAnimation(animationStyle: .expand, completion:
                {
                    if self.email.text != "" &&  self.pass.text != "" && self.user.text != "" && self.cpass.text != ""
                    {
                        if val.isValidUsername(user: self.user.text!)
                        {
                            if val.isValidEmail(email: self.email.text!)
                            {
                                    if val.isValidPassword(pwd: self.pass.text!)
                                    {
                                        if val.isValidCPassword(pwd: self.pass.text!, cpass: self.cpass.text!)
                                        {
                                            let url = URL(string: "http://localhost/KrimaDB/RegisterInsert.php")
                                            let dic = ["uname" : self.user.text!,"email" : self.email.text!,"pass" : self.pass.text!]
                                            do
                                            {
                                                let jsondata = try JSONSerialization.data(withJSONObject: dic, options: [])
                                                var request = URLRequest(url: url!);
                                                request.addValue(String(jsondata.count), forHTTPHeaderField: "Content-Length")
                                                request.httpBody = jsondata
                                                request.httpMethod = "POST"
                                                let session = URLSession.shared;
                                                let datatask = session.dataTask(with: request, completionHandler: { (data1, resp, err) in
                                                    DispatchQueue.main.async {
                                                        let strrep = String(data: data1!, encoding: String.Encoding.utf8)
                                                        if strrep! == "Successful"
                                                        {
                                                            let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
                                                            self.navigationController?.pushViewController(stb!, animated: true)
                                                            let regUser = UserDefaults.standard
                                                            regUser.set(self.email.text!, forKey: "RegUser")
                                                            print(regUser)
                                                        }
                                                    }
                                                })
                                                datatask.resume()
                                            }
                                            catch{}
                                        }
                                        else
                                        {
                                            let alt = UIAlertController(title: "Invalid data", message: "Confirm password doesn't match the actual password", preferredStyle: .alert)
                                            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                            alt.addAction(ok)
                                            self.present(alt, animated: true, completion: nil)
                                            self.cpass.becomeFirstResponder()
                                        }
                                    }
                                    else
                                    {
                                        let alt = UIAlertController(title: "Invalid data", message: "Please enter valid password", preferredStyle: .alert)
                                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                        alt.addAction(ok)
                                        self.present(alt, animated: true, completion: nil)
                                        self.pass.becomeFirstResponder()
                                    }
                            }
                            else
                            {
                                let alt = UIAlertController(title: "Invalid data", message: "Please enter valid email", preferredStyle: .alert)
                                let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                alt.addAction(ok)
                                self.present(alt, animated: true, completion: nil)
                                self.email.becomeFirstResponder()
                            }
                        }
                        else
                        {
                            let alt = UIAlertController(title: "Invalid data", message: "Please enter valid username", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                            alt.addAction(ok)
                            self.present(alt, animated: true, completion: nil)
                            self.user.becomeFirstResponder()
                        }
                    }
                    else
                    {
                        let alt = UIAlertController(title: "Invalid data", message: "Please enter details", preferredStyle: .alert)
                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                        alt.addAction(ok)
                        self.present(alt, animated: true, completion: nil)
                        self.user.becomeFirstResponder()
                    }
                    //let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
                    //self.navigationController?.pushViewController(stb!, animated: true)
                })
            })
        })
    }
}


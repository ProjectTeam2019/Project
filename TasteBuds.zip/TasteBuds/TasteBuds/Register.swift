import UIKit
import SkyFloatingLabelTextField
import TransitionButton

var val = Validation()
class Register: UIViewController
{
    let cont = Controls()
    
    var reg = TransitionButton()
    var user = SkyFloatingLabelTextField()
    var email = SkyFloatingLabelTextField()
    var pass = SkyFloatingLabelTextField()
    var cpass = SkyFloatingLabelTextField()
    @IBOutlet weak var regView: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let nav = navigationController
        nav?.isNavigationBarHidden = false
        self.regView.layer.cornerRadius = 10
        regView.layer.masksToBounds = false
        regView.layer.shadowOffset = CGSize(width: 2, height: 2)
        regView.layer.shadowOpacity = 0.9
        regView.layer.opacity = 0.9
        
        txtField()
        btn()
    }
    func btn()
    {
        reg = cont.custombutton(frame: CGRect(x: 115, y: 359, width: 100, height: 30), bgcolor: UIColor.lightGray, title: "INSCRIBE", radius: 20, spicolor: UIColor.white)
        
        reg.addTarget(self, action: #selector(self.btnReg), for: .touchUpInside)
        self.regView.addSubview(reg)
    }
    
    
    func txtField()
    {
        user = cont.customtext(frame: CGRect(x: 53, y: 59, width: 237, height: 40), placeholder: "Username", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Username Here", selTitleCol: UIColor.purple, secure: false)
        self.regView.addSubview(user)
        
        email = cont.customtext(frame: CGRect(x: 53, y: 129, width: 237, height: 40), placeholder: "Email ID", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Email ID Here", selTitleCol: UIColor.purple, secure: false)
        email.addTarget(self, action: #selector(self.actEmail), for: .editingChanged)
        self.regView.addSubview(email)
        
        pass = cont.customtext(frame: CGRect(x: 53, y: 199, width: 237, height: 40), placeholder: "Password", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Password Here", selTitleCol: UIColor.purple, secure: true)
        pass.addTarget(self, action: #selector(self.actPass), for: .editingChanged)
        self.regView.addSubview(pass)
        
        cpass = cont.customtext(frame: CGRect(x: 53, y: 269, width: 237, height: 40), placeholder: "Confirm Password", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Confirm Password Here", selTitleCol: UIColor.purple, secure: true)
        self.regView.addSubview(cpass)
    }
        
    @objc func actEmail()
    {
        if val.isValidEmail(email: email.text!) {
            
            email.rightViewMode = .never
            email.clipsToBounds = true
            email.layer.borderWidth = 1
            email.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            email.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "error@2x.png"))
            email.rightView = imgview
            
            email.clipsToBounds = true
            email.layer.borderWidth = 1
            email.layer.borderColor = UIColor.red.cgColor
        }
        //lblInstruction.text = "Enter in this format : Firstpart@secondPart.domainname"
    }
    func actUser()
    {
        
    }
    @objc func actPass()
    {
        if val.isValidPassword(pwd: pass.text!) {
            
            pass.rightViewMode = .never
            pass.clipsToBounds = true
            pass.layer.borderWidth = 1
            pass.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            pass.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "error@2x.png"))
            pass.rightView = imgview
            pass.clipsToBounds = true
            pass.layer.borderWidth = 1
            pass.layer.borderColor = UIColor.red.cgColor
        }
        //lblInstruction.text = "Enter in this format : Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:"
    }
    func actCpass()
    {
        
    }
    
    @objc func btnReg()
    {
        reg.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute: {
            
            sleep(3)
            DispatchQueue.main.async(execute: { () -> Void in
                self.reg.stopAnimation(animationStyle: .expand, completion: {
                    
                    
                    //let url = URL(string: "http://localhost/KrimaDB/JsonInsertWithoutImage.php?uname=\()")
                    
                    if self.email.text != "" &&  self.pass.text != ""
                    {
                        if val.isValidEmail(email: self.email.text!)
                        {
                            if val.isValidPassword(pwd: self.pass.text!)
                                {
                                    print("Success")
                                }
                                else
                                {
                                    let alt = UIAlertController(title: "Alert", message: "Please enter valid password", preferredStyle: .alert)
                                    alt.addTextField(configurationHandler: { (pass) in
                                        pass.placeholder = "Enter password"
                                    })
                                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                    alt.addAction(ok)
                                    self.present(alt, animated: true, completion: nil)
                                    
                                   // print("Enter valid password!")
                                }
                        }
                        else
                        {
                            print("Enter valid e_mail!")
                        }
                    }
                    else
                    {
                        print("Kindly enter fully detail")
                    }

                    
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
                    self.navigationController?.pushViewController(stb!, animated: true)
                })
            })
        })
        
        
    }
}

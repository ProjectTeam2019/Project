import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class Register: UIViewController
{
    let cont = Controls()
    var reg = TransitionButton()
    
    @IBOutlet weak var regView: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let nav = navigationController
        nav?.isNavigationBarHidden = false
        self.regView.layer.cornerRadius = 10
        regView.layer.masksToBounds = false
        regView.layer.shadowOffset = CGSize(width: 2, height: 2)
        regView.layer.shadowOpacity = 0.9
        regView.layer.opacity = 0.9
        
        txtField()
        
        reg = TransitionButton(frame: CGRect(x: 115, y: 359, width: 100, height: 30))
        reg.backgroundColor = UIColor.lightGray
        reg.setTitle("INSCRIBE", for: .normal)
        reg.cornerRadius = 20
        reg.spinnerColor = UIColor.white
        
        reg.addTarget(self, action: #selector(self.btnReg), for: .touchUpInside)
        self.regView.addSubview(reg)
        
    }
    func txtField()
    {
        let user = cont.customtext(frame: CGRect(x: 53, y: 59, width: 237, height: 40), placeholder: "Username", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Username Here", selTitleCol: UIColor.purple, secure: false)
        self.regView.addSubview(user)
        
        let email = cont.customtext(frame: CGRect(x: 53, y: 129, width: 237, height: 40), placeholder: "Email ID", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Email ID Here", selTitleCol: UIColor.purple, secure: false)
        self.regView.addSubview(email)
        
        let pass = cont.customtext(frame: CGRect(x: 53, y: 199, width: 237, height: 40), placeholder: "Password", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Password Here", selTitleCol: UIColor.purple, secure: false)
        pass.isSecureTextEntry = true
        self.regView.addSubview(pass)
        
        let cpass = cont.customtext(frame: CGRect(x: 53, y: 269, width: 237, height: 40), placeholder: "Confirm Password", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Confirm Password Here", selTitleCol: UIColor.purple, secure: false)
        cpass.isSecureTextEntry = true
        self.regView.addSubview(cpass)
    }
    @objc func btnReg()
    {
        reg.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute: {
            
            sleep(3)
            DispatchQueue.main.async(execute: { () -> Void in
                self.reg.stopAnimation(animationStyle: .expand, completion: {
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
                    self.navigationController?.pushViewController(stb!, animated: true)
                     //self.navigationController?.popToViewController(stb!, animated: true)
                    //self.navigationController?.popToViewController((self.navigationController?.viewControllers[2])!, animated: true)
                })
            })
        })
    }
}

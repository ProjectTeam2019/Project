
import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class GroceryList: UIViewController
{
    
    @IBOutlet weak var groceryView: UIView!
    
    let objNav = NavigationBar()
    var cont = Controls()
    
    var add = TransitionButton()
    var addIng = SkyFloatingLabelTextField()
    var addBtn = UIButton(type: .custom)
    var cancelBtn = UIButton(type: .custom)
    
    var navbar = UINavigationBar()
    var searchBarItem = UIBarButtonItem()
    var sideBarItem = UIBarButtonItem()
    
    let searchBtn = UIButton(type: .custom)
    let sideBtn = UIButton(type: .custom)
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        
        //addText()
        addButton()
        navigationItems()
    }
    
    func navigationItems()
    {
        //let navbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        navbar = UINavigationBar(frame: CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 43.5))
        let navitem = UINavigationItem(title: "TASTE BUDS")
        
        searchBarItem = objNav.createNavItem(btn: searchBtn, image: "searchicon.png", btnFrame: CGRect(x: self.view.frame.size.width - 53, y: 0, width: 53, height: 30))
        sideBarItem = objNav.createNavItem(btn: sideBtn, image: "sidebar.png", btnFrame: CGRect(x: 0, y: 0, width: 30, height: 30))
        
        searchBtn.addTarget(self, action: #selector(self.searchAction), for: .touchUpInside)
        sideBtn.addTarget(self, action: #selector(self.sidebarAction), for: .touchUpInside)

        navitem.leftBarButtonItem = sideBarItem
        navitem.rightBarButtonItem = searchBarItem
        navbar.items = [navitem]
        self.view.addSubview(navbar)
    }
    
    
    @objc func sidebarAction()
    {
        print("sidebar")
    }
    
    @objc func searchAction()
    {
        print("search")
        addIng = cont.customtext(frame: CGRect(x: 53, y: 0, width: 237, height: 40), placeholder: "Ingredient", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Add Ingredient", selTitleCol: UIColor.blue, secure: false)
        //self.groceryView.addSubview(addIng)
        self.navbar.addSubview(addIng)
        
    }
    
    func addText()
    {
        addIng = cont.customtext(frame: CGRect(x: 40, y: 90, width: 237, height: 40), placeholder: "Ingredient", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Add Ingredient", selTitleCol: UIColor.blue, secure: false)
        self.groceryView.addSubview(addIng)
    }
    func addButton()
    {
        add = cont.custombutton(frame: CGRect(x: 140, y: 500, width: 100, height: 30), bgcolor: UIColor.gray, title: "ADD", radius: 20, spicolor: UIColor.white)
        add.addTarget(self, action: #selector(self.btnAction), for: .touchUpInside)
        self.groceryView.addSubview(add)
        
        let Addimg = UIImage(named: "add1.png")
        addBtn.frame = CGRect(x: 250, y: 70, width: 50, height: 30)
        addBtn.setImage(Addimg, for: .normal)
        addBtn.addTarget(self, action: #selector(self.addBtnAction), for: .touchUpInside)
        self.groceryView.addSubview(addBtn)
        
        let Cancelimg = UIImage(named: "blackcross.png")
        cancelBtn.frame = CGRect(x: 300, y: 70, width: 50, height: 30)
        cancelBtn.setImage(Cancelimg, for: .normal)
        cancelBtn.addTarget(self, action: #selector(self.cancelBtnAction), for: .touchUpInside)
        self.groceryView.addSubview(cancelBtn)
    }
    
    @objc func addBtnAction()
    {
        addText()
    }
    @objc func cancelBtnAction()
    {
        print("Cancel")
    }
    
    @objc func btnAction()
    {
        add.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute:
            {
                sleep(3)
                DispatchQueue.main.async(execute:
                    { () -> Void in
                        self.add.stopAnimation(animationStyle: .expand, completion: {
                    let secondVC = UIViewController()
                    self.present(secondVC, animated: true, completion: nil)
                })
            })
        })
    }
}



import UIKit
import TransitionButton

class skip: UIViewController {

    @IBOutlet weak var skipview: UIView!
    
        var cont = Controls()
      var login = TransitionButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.skipview.layer.cornerRadius = 10
        skipview.layer.masksToBounds = false
        skipview.layer.shadowOffset = CGSize(width: 2, height: 2)
        skipview.layer.shadowOpacity = 0.8
        skipview.layer.opacity = 0.8
        
        addBtn()
        
    }
    
    
    func addBtn()
    {
        login = cont.custombutton(frame: CGRect(x: 135, y: 279, width: 90, height: 30), bgcolor: UIColor.gray, title: "GET IN", radius: 20, spicolor: UIColor.white)
        login.addTarget(self, action: #selector(self.btnLogin), for: .touchUpInside)
        self.skipview.addSubview(login)
        
    }

    @objc func btnLogin()
    {
        
    }

}

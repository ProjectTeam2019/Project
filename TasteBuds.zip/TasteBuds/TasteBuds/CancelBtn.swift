
import UIKit

class CancelBtn: NSObject
{
    func btncancel() -> UIButton
    {
        let btn = UIButton(type: .custom)
        btn.setImage(UIImage(named: "blackcross.png"), for: .normal)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        return btn
    }
}

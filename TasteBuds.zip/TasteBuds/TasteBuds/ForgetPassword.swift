
import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class ForgetPassword: UIViewController
{

    @IBOutlet weak var fgView: UIView!
    let cont = Controls()
    
    var send = TransitionButton()
    var email = SkyFloatingLabelTextField()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        addBtn()
        addTxt()
    }
    
    func addTxt()
    {
        email = cont.customtext(frame: CGRect(x: 53, y: 79, width: 237, height: 40), placeholder: "Username", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Username Here", selTitleCol: UIColor.blue, secure: false)
        self.fgView.addSubview(email)
    }
    
    func addBtn()
    {
        send = TransitionButton(frame: CGRect(x: 115, y: 359, width: 100, height: 30))
        send.backgroundColor = UIColor.lightGray
        send.setTitle("INSCRIBE", for: .normal)
        send.cornerRadius = 20
        send.spinnerColor = UIColor.white
        
        send.addTarget(self, action: #selector(self.btnSend), for: .touchUpInside)
        self.fgView.addSubview(send)
    }
    
    @objc func btnSend()
    {
        
    }
    
}

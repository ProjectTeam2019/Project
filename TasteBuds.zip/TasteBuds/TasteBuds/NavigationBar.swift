

import UIKit

class NavigationBar: NSObject
{
    func createNavItem(btn:UIButton,image:String,btnFrame:CGRect) -> UIBarButtonItem
    {
        let button = btn
        button.setImage(UIImage(named: image), for: .normal)
        button.frame = btnFrame
        let btnitem = UIBarButtonItem(customView: btn)
        return btnitem
    }
}

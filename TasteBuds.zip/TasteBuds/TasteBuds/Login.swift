
import UIKit
import SkyFloatingLabelTextField
import TransitionButton
import EasySocialButton


class Login: UIViewController
{
    
    @IBAction func frgPass(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "forgetPass")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    @IBOutlet var loginview: UIView!
    
    var cont = Controls()
    var login = TransitionButton()
   
    var user = SkyFloatingLabelTextField()
    var pass = SkyFloatingLabelTextField()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        self.loginview.layer.cornerRadius = 10
        loginview.layer.masksToBounds = false
        loginview.layer.shadowOffset = CGSize(width: 2, height: 2)
        loginview.layer.shadowOpacity = 0.9
        loginview.layer.opacity = 0.9
        
        addText()
        social()
        addBtn()
    }
    
    func social()
    {
        let socialbtn = AZSocialButton(frame: CGRect(x: 40, y: 389, width: 310, height: 45))
        
        socialbtn.animateInteraction = true
        socialbtn.useCornerRadius = true
        socialbtn.cornerRadius = 5
        socialbtn.highlightOnTouch = false
        socialbtn.setImage(UIImage(named: "google.png"), for: .normal)
        //socialbtn.image = ImageLiteralType(resourceName: "ic_google")
        socialbtn.setTitle("   Sign in with Google", for: [])
        socialbtn.setTitleColor(.black, for: [])
        socialbtn.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        
        socialbtn.onClickAction = { (button) in
            print("do social login stuff")
        }
        
        view.addSubview(socialbtn)
        
        let fb = AZSocialButton(frame: CGRect(x: 40, y: 460, width: 310, height: 45))
        fb.animateInteraction = true
        fb.useCornerRadius = true
        fb.cornerRadius = 5
        fb.highlightOnTouch = false
        fb.backgroundColor = UIColor.blue
        fb.setImage(UIImage(named: "fb.png"), for: .normal)
        fb.setTitle("   Sign in with Facebook", for: [])
        fb.setTitleColor(.blue, for: [])
        fb.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        fb.onClickAction = { (button) in
            print("do social login stuff")
        }
        
        view.addSubview(fb)
        
        let reg = AZSocialButton(frame: CGRect(x: 40, y: 531, width: 310, height: 45))
        
        reg.animateInteraction = true
        reg.useCornerRadius = true
        reg.cornerRadius = 5
        reg.highlightOnTouch = false
        reg.setImage(UIImage(named: "door.png"), for: .normal)
        reg.setTitle("   Register Yourself", for: [])
        reg.setTitleColor(.black, for: [])
        reg.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        reg.onClickAction = { (button) in
            print("do social login stuff")
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "register")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        view.addSubview(reg)
    }
    
    func addBtn()
    {
        login = cont.custombutton(frame: CGRect(x: 135, y: 279, width: 90, height: 30), bgcolor: UIColor.lightGray, title: "GET IN", radius: 20, spicolor: UIColor.white)
        login.addTarget(self, action: #selector(self.btnLogin), for: .touchUpInside)
        self.loginview.addSubview(login)

    }
    
    func addText()
    {
        user = cont.customtext(frame: CGRect(x: 53, y: 79, width: 237, height: 40), placeholder: "Email", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Email Here", selTitleCol: UIColor.blue, secure: false)
        self.loginview.addSubview(user)
        
        pass = cont.customtext(frame: CGRect(x: 53, y: 149, width: 237, height: 40), placeholder: "Password", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Password Here", selTitleCol: UIColor.blue, secure: true)
            self.loginview.addSubview(pass)
    }
    
    @objc func btnLogin()
   {
    login.startAnimation()
            let qualityOfServiceClass = DispatchQoS.QoSClass.background
            let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
            backgroundQueue.async(execute: {
                
                sleep(3)
                DispatchQueue.main.async(execute: { () -> Void in
                    self.login.stopAnimation(animationStyle: .expand, completion: {
                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
                        self.navigationController?.pushViewController(stb!, animated: true)
                    })
                })
            })
    }
}



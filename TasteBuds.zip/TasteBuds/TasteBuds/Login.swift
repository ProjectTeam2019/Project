
import UIKit
import TransitionButton

class Login: UIViewController
{
    @IBOutlet var loginview: UIView!
    var login = TransitionButton(frame: CGRect(x: 200, y: 400, width: 70, height: 30))
    
    override func viewDidLoad()
    {
        
        super.viewDidLoad()
        
        /*self.Loginview.backgroundColor = UIColor(colorLiteralRed: 17.0/255.0, green: 180.0/255.0, blue: 255.0/255.0, alpha: 1.0)
         self.Loginview.layer.masksToBounds = false
         Loginview.layer.shadowOpacity = 0.5*/
        
        
        self.loginview.layer.cornerRadius = 10
        loginview.layer.masksToBounds = false
        loginview.layer.shadowOffset = CGSize(width: 2, height: 2)
        loginview.layer.shadowOpacity = 0.9
        loginview.layer.opacity = 0.9
    
    
        login.backgroundColor = .red
        login.setTitle("GET IN", for: .normal)
        login.cornerRadius = 20
        login.spinnerColor = .white
        login.addTarget(self, action: #selector(self.btnLogin), for: .touchUpInside)
        self.view.addSubview(login)
    
    }
    
    @objc func btnLogin()
    {
        login.startAnimation() // 2: Then start the animation when the user tap the button
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute: {
            
            sleep(3) // 3: Do your networking task or background work here.
            
            DispatchQueue.main.async(execute: { () -> Void in
                // 4: Stop the animation, here you have three options for the `animationStyle` property:
                // .expand: useful when the task has been compeletd successfully and you want to expand the button and transit to another view controller in the completion callback
                // .shake: when you want to reflect to the user that the task did not complete successfly
                // .normal
                self.login.stopAnimation(animationStyle: .expand, completion: {
                    let secondVC = UIViewController()
                    self.present(secondVC, animated: true, completion: nil)
                })
            })
        })
    }
}



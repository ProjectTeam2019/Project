
import UIKit
import SkyFloatingLabelTextField
import TransitionButton
import EasySocialButton


class Login: UIViewController
{
    //@IBOutlet weak var socialbtn: AZSocialButton!
    @IBOutlet var loginview: UIView!
    
    var cont = Controls()
    var login = TransitionButton()
    override func viewDidLoad()
    {
        
        super.viewDidLoad()
        
        self.loginview.layer.cornerRadius = 10
        loginview.layer.masksToBounds = false
        loginview.layer.shadowOffset = CGSize(width: 2, height: 2)
        loginview.layer.shadowOpacity = 0.9
        loginview.layer.opacity = 0.9
        
        addText()
        social()
        
        login = TransitionButton(frame: CGRect(x: 125, y: 203, width: 90, height: 30))
        login.backgroundColor = UIColor.lightGray
        login.setTitle("GET IN", for: .normal)
        login.cornerRadius = 20
        login.spinnerColor = UIColor.white
        
        login.addTarget(self, action: #selector(self.btnLogin), for: .touchUpInside)
        self.loginview.addSubview(login)
        
    }
    
    func social()
    {
        let socialbtn = AZSocialButton(frame: CGRect(x: 40, y: 389, width: 290, height: 45))
        
        socialbtn.animateInteraction = true
        socialbtn.useCornerRadius = true
        socialbtn.cornerRadius = 5
        socialbtn.highlightOnTouch = false
        //socialbtn.image = ImageLiteralType(resourceName: "ic_google")
        socialbtn.setTitle("Sign in with Google", for: [])
        socialbtn.setTitleColor(.black, for: [])
        socialbtn.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        
        socialbtn.onClickAction = { (button) in
            print("do social login stuff")
        }
        
        view.addSubview(socialbtn)
        
        let fb = AZSocialButton(frame: CGRect(x: 40, y: 460, width: 290, height: 45))
        
        fb.animateInteraction = true
        fb.useCornerRadius = true
        fb.cornerRadius = 5
        fb.highlightOnTouch = false
        //fb.image = ImageLiteralType(resourceName: "ic_fb")
        fb.backgroundColor = UIColor.blue
        fb.setTitle("Sign in with Facebook", for: [])
        fb.setTitleColor(.black, for: [])
        fb.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        
        fb.onClickAction = { (button) in
            print("do social login stuff")
        }
        
        view.addSubview(fb)
    }
    
    func addText()
    {
        let user = cont.customtext(frame: CGRect(x: 53, y: 59, width: 237, height: 40), placeholder: "Username", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Username Here", selTitleCol: UIColor.purple, secure: false)
        self.loginview.addSubview(user)
        
        let pass = cont.customtext(frame: CGRect(x: 53, y: 129, width: 237, height: 40), placeholder: "Password", selLineCol: UIColor.purple, selLineHei: 2, selTitle: "Password Here", selTitleCol: UIColor.purple, secure: true)
        self.loginview.addSubview(pass)
    }
    
    @objc func btnLogin()
   {
    login.startAnimation()
            let qualityOfServiceClass = DispatchQoS.QoSClass.background
            let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
            backgroundQueue.async(execute: {
                
                sleep(3)
                DispatchQueue.main.async(execute: { () -> Void in
                    self.login.stopAnimation(animationStyle: .expand, completion: {
                        let secondVC = UIViewController()
                        self.present(secondVC, animated: true, completion: nil)
                    })
                })
            })
        }
}



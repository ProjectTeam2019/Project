
import UIKit
import SkyFloatingLabelTextField
import TransitionButton
import EasySocialButton
import FBSDKLoginKit
import GoogleSignIn

class Login: UIViewController,FBSDKLoginButtonDelegate, GIDSignInUIDelegate, GIDSignInDelegate
{
   let objView = ViewOpacity()
   
    @IBAction func frgPass(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "forgetPass")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    
    @IBOutlet var loginview: UIView!
    
    var cont = Controls()
    var login = TransitionButton()
   
    var user = SkyFloatingLabelTextField()
    var pass = SkyFloatingLabelTextField()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let signInButton = GIDSignInButton(frame: CGRect(x: 40, y: 389, width: 310, height: 45))
        GIDSignIn.sharedInstance().delegate = self
        
        GIDSignIn.sharedInstance().uiDelegate = self
        
        
        signInButton.style = .wide
        
        self.view.addSubview(signInButton)
        NotificationCenter.default.addObserver(self,selector:#selector(self.receiveToggleAuthUINotification(_:)),name: NSNotification.Name(rawValue: "ToggleAuthUINotification"),object:nil)
        
        navigationController?.navigationBar.isHidden = true
        let loginButton = FBSDKLoginButton(frame: CGRect(x: 40, y: 460, width: 310, height: 45))
        loginButton.readPermissions = ["email"]
        loginButton.delegate = self
        self.view.addSubview(loginButton)
        
        let dif = UserDefaults.standard
        
        if (dif.value(forKey: "uname") != nil)
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        
        
        self.loginview.layer.cornerRadius = 10
        objView.viewOp(vw: loginview)
       
        addText()
        social()
        addBtn()
     
    }
 
    @objc func receiveToggleAuthUINotification(_ notification: NSNotification) {
        if notification.name.rawValue == "ToggleAuthUINotification" {
    
            if notification.userInfo != nil {
                guard let userInfo = notification.userInfo as? [String:String] else { return }
                
            }
        }
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
            // [START_EXCLUDE silent]
            NotificationCenter.default.post(
                name: Notification.Name(rawValue: "ToggleAuthUINotification"), object: nil, userInfo: nil)
            // [END_EXCLUDE]
        } else {
            // Perform any operations on signed in user here.
            let userId = user.userID                  // For client-side use only!
            let idToken = user.authentication.idToken // Safe to send to the server
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            let Image_Url = user.profile.imageURL(withDimension: UInt(0.6))
            
            let dif = UserDefaults.standard
            
            dif.setValue(fullName, forKey: "uname")
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
                self.navigationController?.pushViewController(stb!, animated: true)
            
            
            print(userId!)
            print(idToken!)
            print(fullName!)
            print(givenName!)
            print(familyName!)
            print(email!)
            
            
            // [START_EXCLUDE]
            NotificationCenter.default.post(
                name: Notification.Name(rawValue: "ToggleAuthUINotification"),
                object: nil,
                userInfo: ["statusText": "Signed in user:\n\(String(describing: fullName))"])
            // [END_EXCLUDE]
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        
        self.tabBarController?.tabBar.isHidden = true
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        getFBUserData()
        print("Login completed")
        
    }
    func loginButtonWillLogin(_ loginButton: FBSDKLoginButton!) -> Bool {
        
        return true
    }
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        
        print("user Logedout")
    }
    
    
    
    func social()
    {
        
        
        let reg = AZSocialButton(frame: CGRect(x: 40, y: 531, width: 310, height: 45))
        
        reg.animateInteraction = true
        reg.useCornerRadius = true
        reg.cornerRadius = 5
        reg.highlightOnTouch = false
        reg.setImage(UIImage(named: "door.png"), for: .normal)
        reg.setTitle("   Register Yourself", for: [])
        reg.setTitleColor(.black, for: [])
        reg.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        reg.onClickAction = { (button) in
            print("do social login stuff")
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "register")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        view.addSubview(reg)
    }
    
    func getFBUserData() {
        let graphRequest = FBSDKGraphRequest(graphPath: "me", parameters: ["fields":"id, email, name, picture.width(480).height(480)"])
        graphRequest?.start(completionHandler: { (connection, result, error) in
            if error != nil {
                print("Error",error!.localizedDescription)
            }
            else{
                print(result!)
                let field = result! as? [String:Any]
                
                //self.userNameLabel.text = "Hello" + (field?["name"] as! String)
                if let imageURL = ((field!["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                    print(imageURL)
                    let url = URL(string: imageURL)
                    let data = NSData(contentsOf: url!)
                    let image = UIImage(data: data! as Data)
 
                let dif = UserDefaults.standard
                    dif.set(field?["name"] as! String, forKey: "uname")
                
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
                    self.navigationController?.pushViewController(stb!, animated: true)
                    
                    
                   
                }
            }
        })
    }
    func addBtn()
    {
        login = cont.custombutton(frame: CGRect(x: 135, y: 279, width: 90, height: 30), bgcolor: UIColor.gray, title: "GET IN", radius: 20, spicolor: UIColor.white)
        login.addTarget(self, action: #selector(self.btnLogin), for: .touchUpInside)
        self.loginview.addSubview(login)

    }
    
    func addText()
    {
        user = cont.customtext(frame: CGRect(x: 53, y: 79, width: 237, height: 40), placeholder: "Email", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Email Here", selTitleCol: UIColor.blue, secure: false)
        self.loginview.addSubview(user)
        
        pass = cont.customtext(frame: CGRect(x: 53, y: 149, width: 237, height: 40), placeholder: "Password", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Password Here", selTitleCol: UIColor.blue, secure: true)
            self.loginview.addSubview(pass)
    }
    
   @objc func btnLogin()
   {
    login.startAnimation()
            let qualityOfServiceClass = DispatchQoS.QoSClass.background
            let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
            backgroundQueue.async(execute:
            {
                sleep(3)
                DispatchQueue.main.async(execute:
                { () -> Void in
                    self.login.stopAnimation(animationStyle: .expand, completion:
                    {
                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
                        self.navigationController?.pushViewController(stb!, animated: true)
                        /*if self.pass.text != "" && self.user.text != ""
                        {
                            let url = URL(string: "http://localhost/KrimaDB/LoginGet.php?email=\(self.user.text!)&pass=\(self.pass.text!)");
                            let request = URLRequest(url: url!);
                            let session = URLSession.shared;
                            let datatask = session.dataTask(with: request)
                            {
                                (data1, resp, err) in
                                let strrep = String(data: data1!, encoding: String.Encoding.utf8)
                                DispatchQueue.main.async
                                    {
                                        do
                                        {
                                            var jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                                            if jsondata.count > 0
                                            {
                                                var dic = jsondata[0] as! [String:String];
                                                let loginUser = UserDefaults.standard;
                                                loginUser.set(dic["email"], forKey: "email");
                                                print(dic["email"]!);
                                                let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
                                                self.navigationController?.pushViewController(stb!, animated: true)
                                            }
                                            else
                                            {
                                                let alt = UIAlertController(title: "Invalid data", message: "Email or password is incorrect", preferredStyle: .alert)
                                                let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                                alt.addAction(ok)
                                                self.present(alt, animated: true, completion: nil)
                                            }
                                        }
                                        catch
                                        {}
                                }
                            }
                            datatask.resume()
                        }
                        else
                        {
                            let alt = UIAlertController(title: "Invalid data", message: "Please enter details", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                            alt.addAction(ok)
                            self.present(alt, animated: true, completion: nil)
                        }*/
                    })
                })
            })
    }
}




import UIKit

class ScanIngredient: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

      
    }
}


import UIKit

class ScanIngredient: UIViewController
{
    @IBOutlet weak var scanView: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

      
    }
}

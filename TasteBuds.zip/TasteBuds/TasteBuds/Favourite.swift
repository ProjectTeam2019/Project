
import UIKit

class Favourite: UIViewController
{
    @IBOutlet weak var favView: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        
    }
}
